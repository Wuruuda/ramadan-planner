// Prayer Times Data
const prayerTimes = {
    fajr: "5:00 AM",
    dhuhr: "12:30 PM",
    asr: "4:00 PM",
    maghrib: "6:15 PM",
    isha: "7:30 PM"
};

// Quran Progress System
let currentPages = 0;
const totalPages = 20;

document.querySelector('.update-button').addEventListener('click', () => {
    currentPages = Math.min(currentPages + 5, totalPages);
    updateProgressBar();
});

function updateProgressBar() {
    const progress = (currentPages / totalPages) * 100;
    document.querySelector('.progress-fill').style.width = `${progress}%`;
}

// Scroll Animations
window.addEventListener('scroll', () => {
    const cards = document.querySelectorAll('.meal-card, .prayer-times');
    cards.forEach(card => {
        const cardTop = card.getBoundingClientRect().top;
        if (cardTop < window.innerHeight) {
            card.classList.add('animate');
        }
    });
});

// Initialize Prayer Times
function initializePrayerTimes() {
    const container = document.getElementById('prayer-times-list');
    Object.entries(prayerTimes).forEach(([prayer, time]) => {
        const prayerItem = document.createElement('div');
        prayerItem.className = 'prayer-item';
        prayerItem.innerHTML = `
            <span>${prayer}</span>
            <span>${time}</span>
        `;
        container.appendChild(prayerItem);
    });
}

// Ramadan Countdown
function updateRamadanCountdown() {
    const ramadanDate = new Date('March 10, 2024').getTime();
    const now = new Date().getTime();
    const difference = ramadanDate - now;
    
    const days = Math.floor(difference / (1000 * 60 * 60 * 24));
    document.getElementById('ramadan-countdown').innerHTML = `
        <span class="countdown-number">${days}</span>
    `;
}

// Dhikr Counter
let dhikrCount = 0;
const dhikrDisplay = document.querySelector('.counter-display');

function incrementDhikr() {
    dhikrCount++;
    dhikrDisplay.textContent = dhikrCount;
    dhikrDisplay.style.animation = 'pulse 0.5s ease';
    setTimeout(() => dhikrDisplay.style.animation = '', 500);
}

function resetDhikr() {
    dhikrCount = 0;
    dhikrDisplay.textContent = '0';
}

// Prayer Times API Integration
async function fetchPrayerTimes() {
    try {
        const response = await fetch('https://api.aladhan.com/v1/timingsByCity?city=Mogadishu&country=Somalia&method=2');
        const data = await response.json();
        const timings = data.data.timings;
        
        const prayers = {
            Fajr: timings.Fajr,
            Dhuhr: timings.Dhuhr,
            Asr: timings.Asr,
            Maghrib: timings.Maghrib,
            Isha: timings.Isha
        };

        updatePrayerTimes(prayers);
    } catch (error) {
        console.error('Error fetching prayer times:', error);
        // Fallback to static times
        updatePrayerTimes({
            Fajr: '4:45 AM',
            Dhuhr: '12:15 PM',
            Asr: '3:30 PM',
            Maghrib: '6:15 PM',
            Isha: '7:30 PM'
        });
    }
}

function updatePrayerTimes(prayers) {
    const prayerList = document.querySelector('.prayer-list');
    prayerList.innerHTML = '';
    
    Object.entries(prayers).forEach(([prayer, time]) => {
        const listItem = document.createElement('li');
        listItem.className = 'prayer-item';
        listItem.innerHTML = `
            <span class="prayer-name">${prayer}</span>
            <span class="prayer-time">${time}</span>
            <div class="prayer-line"></div>
        `;
        prayerList.appendChild(listItem);
    });
}

// Initialize
updateRamadanCountdown();
fetchPrayerTimes();
setInterval(updateRamadanCountdown, 86400000); // Update countdown daily



initializePrayerTimes();